package com.miguelbcr.tablefixheaderssamples.adapters.original_sortable;

/**
 * Created by miguel on 05/03/2016.
 */
public class ItemSortableCheckBox extends  ItemSortable {
    public boolean orderSectionsAsc;

    public ItemSortableCheckBox(String text) {
        super(text);
    }
}
